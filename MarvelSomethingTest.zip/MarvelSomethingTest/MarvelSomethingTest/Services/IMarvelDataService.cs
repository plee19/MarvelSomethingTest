﻿using System;
namespace MarvelSomethingTest.Services
{
    public class IMarvelDataService
    {
        public IMarvelDataService()
        {
        }
    }
}
