﻿using System;
namespace MarvelSomethingTest.Services
{
    public class IHashService
    {
        public IHashService()
        {
        }
    }
}
