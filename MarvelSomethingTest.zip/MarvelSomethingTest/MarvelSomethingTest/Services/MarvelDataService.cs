﻿
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using MarvelSomethingTest.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MarvelSomethingTest.Services
{
    public class MarvelDataService : IMarvelDataService
    {
        // TODO: Add your Marvel Developer Account keys
        const string _API_PRIVATE_KEY = "ba4bd24a5fc216100628d3f472112e5c3880a29c";
        const string _API_PUBLIC_KEY = "70805b474b4ec3b3cdc6db9e19d9d9b2";

        readonly IHashService _hashService;

        public MarvelDataService(IHashService hashService)
        {
            _hashService = hashService;
        }

        public async Task<IEnumerable<Series>> GetComicsBySeries(int seriesId, string orderBy = null)
        {
            var ts = Guid.NewGuid().ToString();
            var hash = _hashService.CreateMd5Hash(ts + _API_PRIVATE_KEY + _API_PUBLIC_KEY);

            if (string.IsNullOrWhiteSpace(orderBy))
                orderBy = "issueNumber";

            var url =
                $@"http://gateway.marvel.com/v1/public/series/17409&apikey={_API_PUBLIC_KEY}&hash={hash}&ts={ts}";

            var client = new HttpClient();
            var response = await client.GetStringAsync(url);

            var responseObject = JObject.Parse(response);

            return await Task.Factory.StartNew(() => JsonConvert.DeserializeObject<IEnumerable<Series>>(responseObject["data"]["results"].ToString()));
        }
    }
}