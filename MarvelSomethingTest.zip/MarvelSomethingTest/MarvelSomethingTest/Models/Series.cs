﻿using System;
namespace MarvelSomethingTest.Models
{
    public class Series
    {
        public Series()
        {
        }
    }
}
