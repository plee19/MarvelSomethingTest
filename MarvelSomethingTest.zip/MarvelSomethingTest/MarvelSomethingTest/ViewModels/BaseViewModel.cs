﻿using System;
namespace MarvelSomethingTest.ViewModels
{
    public class BaseViewModel
    {
        public BaseViewModel()
        {
        }
    }
}
